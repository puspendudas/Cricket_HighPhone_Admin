import { BASE_URL } from '../BaseURL/BaseURL';

export const Endpoints = {
    // Allemployee

    Allemployee:`${BASE_URL}/api/v1/employees`,
    Department:`${BASE_URL}/api/v1/departments`,
    Roles:`${BASE_URL}/api/v1/roles`,
    leaves:`${BASE_URL}/api/v1/leaves`,
    payroll:`${BASE_URL}/api/v1/payrolls`,
    attendance:`${BASE_URL}/api/v1/attendance`,



    

}



