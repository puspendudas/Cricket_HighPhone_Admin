export const BASE_URL = 'https://api.pmithrms.in.net';
