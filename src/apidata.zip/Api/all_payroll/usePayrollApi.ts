import type { Payroll } from '@/src/Interface/payrollview.interface ';

import { useCallback } from 'react';

import useApi from 'src/server/axios/index';
import { Endpoints } from 'src/server/endpoints_configuration/Endpoints';

const usePayrollApi = () => {
  const { get, put, post } = useApi();

  // Get Api for employeeData

  const fetchAllEmployees = useCallback(async () => {
    try {
      const response = await get(Endpoints.Allemployee);
      return response.data;
    } catch (error) {
      console.error('Error fetching employees:', error);
      return [];
    }
  }, [get]);

  // Get Api for employee name
  const fetchEmployeesByid = useCallback(async (employee_id: string) => {
    try {
      const response = await get(`${Endpoints.Allemployee}/${employee_id}`); 
      return response.data;
    } catch (error) {
      console.error('Error fetching employee:', error);
      return null; // Return null if the employee is not found
    }
  }, [get]);
  
  const fetchAllPayroll = async () => {
    try {
      const response = await get(Endpoints.payroll);

      return response.data;
    } catch (error) {
      console.error('Error fetching payroll:', error);
      return [];
    }
  };

  // Add new Employee Api

  const addPayroll = async (data: Payroll) => {
    try {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { _id, ...payrollData } = data;
      const response = await post(Endpoints.payroll, payrollData);
      return response.data;
    } catch (error) {
      console.error('Error adding payroll:', error);
      throw error;
    }
  };

  // Update Api
  const updatePayroll = async (_id: string, data: Payroll) => {
    try {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { _id: idToUpdate, ...payrollData } = data;
      const response = await put(`${Endpoints.payroll}/${_id}`, payrollData);
      return response.data;
    } catch (error) {
      console.error('Error updating payroll:', error);
      throw error;
    }
  };


  return { fetchAllPayroll, updatePayroll, addPayroll,fetchEmployeesByid ,fetchAllEmployees};
};

export default usePayrollApi;
