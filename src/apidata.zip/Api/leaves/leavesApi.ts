import type { Data } from '@/src/Interface/leaves.nterface';

import { useCallback } from 'react';

import useApi from 'src/server/axios/index';
import { Endpoints } from 'src/server/endpoints_configuration/Endpoints';

const useLeavesApi = () => {
  const { get, put } = useApi();

  // Get Api

  const fetchEmployeesByid = useCallback(async (employee_id: string) => {
    try {
      const response = await get(`${Endpoints.Allemployee}/${employee_id}`); 
      return response.data;
    } catch (error) {
      console.error('Error fetching employee:', error);
      return null; // Return null if the employee is not found
    }
  }, [get]);

  
  const fetchLeave = async (): Promise<{ data: Data[]; rejectedLeaves: Data[] }> => {
    try {
      const response = await get(Endpoints.leaves);
      const leavesData: Data[] = response.data.map((leave: any) => {
        const startDate = new Date(leave.start_date);
        const endDate = new Date(leave.end_date);
        const diffTime = endDate.getTime() - startDate.getTime();
        const days = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
        return {
          ...leave,
          start_date: startDate,
          end_date: endDate,
          applyingDate: leave.applyingDate ? new Date(leave.applyingDate) : undefined,
          days, 
        };
      });

      const rejectedLeaves = leavesData.filter(leave => leave.status === "Unapproved");

      return { data: leavesData, rejectedLeaves };
    } catch (error) {
      console.error('Error fetching leaves:', error);
      return { data: [], rejectedLeaves: [] };
    }
  };

  // Update existing leaves
  const updateLeave = async (_id: string, updatedData: { status: string; review: string }) => {
    try {
      const response = await put(`${Endpoints.leaves}/${_id}`, updatedData);
      return response.data;
    } catch (error) {
      console.error('Error updating:', error);
      throw error;
    }
  };

  return { fetchLeave, updateLeave,fetchEmployeesByid };
};


export default useLeavesApi;