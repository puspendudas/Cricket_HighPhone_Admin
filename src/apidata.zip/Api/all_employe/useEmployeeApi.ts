// useEmployeeApi.ts
import type { EmployeeTableData } from '@/src/Interface/all_employee.interface';

import { useCallback } from 'react';

import useApi from 'src/server/axios/index';
import { Endpoints } from 'src/server/endpoints_configuration/Endpoints';

const useEmployeeApi = () => {
  const { get, post, put, deleted } = useApi();

  // Memoized function to fetch all employees
  const fetchAllEmployees = useCallback(async () => {
    try {
      const response = await get(Endpoints.Allemployee);
      return response.data;
    } catch (error) {
      console.error('Error fetching employees:', error);
      return [];
    }
  }, [get]);

  // Memoized function to add a new employee
  const addEmployee = useCallback(async (data: EmployeeTableData) => {
    try {
      const response = await post(Endpoints.Allemployee, data);
      return response.data;
    } catch (error) {
      console.error('Error adding employee:', error);
      throw error;
    }
  }, [post]);

  // Memoized function to update an employee
  const updateEmployee = useCallback(async (_id: string, data: any) => {
    console.log(_id, 'idddddddddddd');
    try {
      const response = await put(`${Endpoints.Allemployee}/${_id}`, data);
      console.log(response, 'responseresponse');
      return response;
    } catch (error) {
      console.error('Error updating employee:', error);
      throw error;
    }
  }, [put]);

  // Memoized function to delete an employee
  const deleteEmployee = useCallback(async (id: string) => {
    try {
      await deleted(`${Endpoints.Allemployee}/${id}`);
    } catch (error) {
      console.error('Error deleting employee:', error);
      throw error;
    }
  }, [deleted]);

  return { fetchAllEmployees, addEmployee, updateEmployee, deleteEmployee };
};

export default useEmployeeApi;
