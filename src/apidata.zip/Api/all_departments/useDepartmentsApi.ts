import type {EditData, Department  } from 'src/Interface/all_department.interface';

import useApi from 'src/server/axios/index';
import { Endpoints } from 'src/server/endpoints_configuration/Endpoints';

const useDepartmentsApi = () => {
  const { get, post, put, deleted } = useApi();

  // Get Api
  const fetchAllDepartments = async (): Promise<{ data: Department[] }> => {
    try {
      const response = await get(Endpoints.Department);
      return response;
    } catch (error) {
      console.error('Error fetching departments:', error);
      return { data: [] };
    }
  };

  // Add new Departments Api
  const addDepartments = async (data: Department) => {
    try {
      const response = await post(Endpoints.Department, data);
      return response.data;
    } catch (error) {
      console.error('Error adding department:', error);
      throw error;
    }
  };

  // Update existing department
  const updateDepartments = async (_id: string, data: EditData) => {
    try {
      const response = await put(`${Endpoints.Department}/${_id}`, data);
      return response.data;
    } catch (error) {
      console.error('Error updating department:', error);
      throw error;
    }
  };

  // Delete department
  const deleteDepartments = async (id: string) => {
    try {
      await deleted(`${Endpoints.Department}/${id}`);
    } catch (error) {
      console.error('Error deleting department:', error);
      throw error;
    }
  };

  return { fetchAllDepartments, addDepartments, updateDepartments, deleteDepartments };
};

export default useDepartmentsApi;
